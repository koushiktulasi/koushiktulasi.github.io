package com.cts.admin.dao;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.cts.admin.model.Admin;
import com.cts.util.Db;

public class AdminDAOImp implements AdminDAO
{
  
  @Override
  public int adminlogin(Admin a) {
                  int result=0;
                  PreparedStatement pst=null;
                  ResultSet rs=null;
                try
                {
                                pst = Db.getDb().prepareStatement("select * from admin");
                                rs=pst.executeQuery();
                                while(rs.next())
                                {
                                                if(a.getUname().equals(rs.getString(1))&&a.getPassword().equals(rs.getString(2)))
                                                {
                                                                result=1;
                                                                break;
                                                                                                
                                                }
                                }
                }
                catch(Exception e)
                {
                                System.out.println(e);
                }
                return result;
}
}

