package com.cts.patient.dao;

import com.cts.patient.model.PatientRegister;

public interface AddPatientDAO {
public  int addpatient(PatientRegister p);
}
