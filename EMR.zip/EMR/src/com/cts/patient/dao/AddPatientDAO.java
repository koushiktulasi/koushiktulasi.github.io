package com.cts.patient.dao;

import java.util.ArrayList;

import com.cts.patient.model.Doctor;
import com.cts.patient.model.PatientRegister;
import com.cts.patient.model.PatientSearch;
import com.cts.patient.model.TreatmentDetails;

public interface AddPatientDAO {
public  int addpatient(PatientRegister p);
public int adddoctor(Doctor dc);
public int addtreatmentdetails(TreatmentDetails tr);
public ArrayList<TreatmentDetails> patientsearch(TreatmentDetails t);
}
