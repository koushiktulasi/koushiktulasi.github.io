package com.cts.patient.dao;

import java.sql.PreparedStatement;
import java.util.ArrayList;

import javax.servlet.http.HttpSession;

import com.cts.patient.model.Doctor;
import com.cts.patient.model.PatientRegister;
import com.cts.patient.model.PatientSearch;
import com.cts.patient.model.TreatmentDetails;
import com.cts.util.Db;
import com.mysql.jdbc.ResultSet;

public class AddPatientDAOImp implements AddPatientDAO{

	@Override
	public int addpatient(PatientRegister p) {
		int result=0;
        PreparedStatement pst=null;
        PreparedStatement pst1=null;
        try
        {
        	pst = Db.getDb().prepareStatement("insert into patient values('"+ p.getFirstName()+"','"+p.getLastName()+"','"
        +p.getAge()+"','"+p.getGender()+"','"+p.getContactNumber()+"','"+p.getUserId()+"','"+p.getPassword()+"');");
        	pst1=Db.getDb().prepareStatement("insert into patientlogin values('"+p.getUserId()+"','"+p.getPassword()+"');");
        	result=pst.executeUpdate();
        	result=pst1.executeUpdate();
        }
        catch(Exception e)
        {
        	System.out.println(e);
        }
		return result;
	}
		
		@Override
		public int adddoctor(Doctor dc) {
			int result=0;
	        PreparedStatement pst=null;
	  
	        try
	        {
	        	pst = Db.getDb().prepareStatement("insert into doctor values('"+ dc.getDoctorid()+"','"+dc.getDoctorname()+"','"
	        +dc.getSpecialist()+"','"+dc.getAppdate()+"');");
	        	
	        	result=pst.executeUpdate();
	        
	        }
	        catch(Exception e)
	        {
	        	System.out.println(e);
	        }
			return result;
	
	
		}

		public int addtreatmentdetails(TreatmentDetails tr) {
			int result=0;
	        PreparedStatement pst=null;
	  
	        try
	        {
	        	pst = Db.getDb().prepareStatement("insert into treatmentdetails values('"+tr.getPatientid()+"','"+tr.getCheckin()+"','"
	        +tr.getIllness()+"','"+tr.getSeriousness()+"','"+tr.getContactnumber()+"','"
	        		+tr.getBloodgroup()+"','"+tr.getHeight()+"','"
	        		+tr.getWeight()+"','"+tr.getAddress()+"','"+tr.getStatus()+"','"+tr.getDoctorname()+"','"+tr.getDoctorid()+"');");
	        	
	        	result=pst.executeUpdate();
	        
	        }
	        catch(Exception e)
	        {
	        //	System.out.println(e);
	        	e.printStackTrace();
	        }
			return result;
	
		}

		@Override
		public ArrayList<TreatmentDetails> patientsearch(TreatmentDetails t) {
			int result=0;
		    PreparedStatement pst=null;
		    ArrayList<TreatmentDetails> al=new ArrayList<>();
		    ResultSet rs=null;
		    try
		    {
		    	
		    
		    	pst=Db.getDb().prepareStatement("select * from treatmentdetails where patientid='"+t.getPatientid()+"'");
		    	rs=(ResultSet) pst.executeQuery();
		    	while(rs.next())
		    	{
		    		TreatmentDetails t1=new TreatmentDetails(rs.getInt(1), rs.getString(2),  rs.getString(3), rs.getString(4), rs.getLong(5),
		    		rs.getString(6),  rs.getInt(7), rs.getInt(8), rs.getString(9), rs.getString(10), rs.getString(11),rs.getInt(12));
		    	al.add(t1);
		    	
		    	}
		    	
		    }
		    catch(Exception e)
		    {
		    	e.printStackTrace();		 
		    	}
		    return al;
		}
}
