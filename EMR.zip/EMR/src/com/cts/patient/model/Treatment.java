package com.cts.patient.model;

public class Treatment {

}
