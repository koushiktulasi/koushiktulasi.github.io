package com.cts.patient.model;

public class TreatmentDetails {

	public int getPatientid() {
		return patientid;
	}
	public void setPatientid(int patientid) {
		this.patientid = patientid;
	}
	public String getCheckin() {
		return checkin;
	}
	public void setCheckin(String checkin) {
		this.checkin = checkin;
	}
	public String getIllness() {
		return illness;
	}
	public void setIllness(String illness) {
		this.illness = illness;
	}
	public String getSeriousness() {
		return seriousness;
	}
	public void setSeriousness(String seriousness) {
		this.seriousness = seriousness;
	}
	public long getContactnumber() {
		return contactnumber;
	}
	public void setContactnumber(long contactnumber) {
		this.contactnumber = contactnumber;
	}
	public String getBloodgroup() {
		return bloodgroup;
	}
	public void setBloodgroup(String bloodgroup) {
		this.bloodgroup = bloodgroup;
	}
	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		this.height = height;
	}
	public int getWeight() {
		return weight;
	}
	public void setWeight(int weight) {
		this.weight = weight;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getDoctorname() {
		return doctorname;
	}
	public void setDoctorname(String doctorname) {
		this.doctorname = doctorname;
	}
	public int getDoctorid() {
		return doctorid;
	}
	public void setDoctorid(int doctorid) {
		this.doctorid = doctorid;
	}
	public TreatmentDetails(int patientid, String checkin, String illness, String seriousness, long contactnumber,
			String bloodgroup, int height, int weight, String address, String status, String doctorname, int doctorid) {
		super();
		this.patientid = patientid;
		this.checkin = checkin;
		this.illness = illness;
		this.seriousness = seriousness;
		this.contactnumber = contactnumber;
		this.bloodgroup = bloodgroup;
		this.height = height;
		this.weight = weight;
		this.address = address;
		this.status = status;
		this.doctorname = doctorname;
		this.doctorid = doctorid;
	}
	
	
private int patientid;
private String checkin;
private String illness;
private String seriousness;
private long contactnumber;
private String bloodgroup;
private int height;
private int weight;
private String address;
private String status;
private String doctorname;
private int doctorid;
public  TreatmentDetails()
{
	
}
}
