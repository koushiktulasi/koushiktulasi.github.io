package com.cts.patient.model;

public class PatientSearch {
	

	
	private String illness,status,seriousness,doctorname,bloodgroup,address,checkin;
	private int height,weight,doctorid;
	private long contactnumber,patientid;
	public String getIllness() {
		return illness;
	}
	public void setIllness(String illness) {
		this.illness = illness;
	}
	public PatientSearch(long patientid,String checkin,String illness,  String seriousness,long contactnumber,String bloodgroup,  
			   int height, int weight,String address,String status,String doctorname,int doctorid) {
		super();
		this.illness = illness;
		this.status = status;
		this.seriousness = seriousness;
		
		this.bloodgroup = bloodgroup;
		this.address = address;
		
		this.contactnumber = contactnumber;
		this.height = height;
		this.weight = weight;
		this.checkin=checkin;
		this.patientid=patientid;
		this.doctorname=doctorname;
		this.doctorid=doctorid;
	}
	public long getPatientid() {
		return patientid;
	}
	public void setPatientid(long patientid) {
		this.patientid = patientid;
	}
	public String getCheckin() {
		return checkin;
	}
	public void setCheckin(String checkin) {
		this.checkin = checkin;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getSeriousness() {
		return seriousness;
	}
	public void setSeriousness(String seriousness) {
		this.seriousness = seriousness;
	}
	public String getDoctorName() {
		return doctorname;
	}
	public void setDoctorassign(String doctorname) {
		this.doctorname = doctorname;
	}
	public int getDoctorid() {
		return doctorid;
	}
	public void setDoctorid(int doctorid) {
		this.doctorid = doctorid;
	}
	public String getBloodgroup() {
		return bloodgroup;
	}
	public void setBloodgroup(String bloodgroup) {
		this.bloodgroup = bloodgroup;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}

	public long getContactnumber() {
		return contactnumber;
	}
	public void setContactnumber(long contactnumber) {
		this.contactnumber = contactnumber;
	}
	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		this.height = height;
	}
	public int getWeight() {
		return weight;
	}
	public void setWeight(int weight) {
		this.weight = weight;
	}
	}


