package com.cts.patient.model;

public class Doctor {
  private String doctorname,specialist,appdate;
  private int doctorid;

  public Doctor(String doctorname, String specialist, String appdate, int doctorid) {
	super();
	this.doctorname = doctorname;
	this.specialist = specialist;
	this.appdate = appdate;
	this.doctorid = doctorid;
}
public int getDoctorid() {
	return doctorid;
}
public void setDoctorid(int doctorid) {
	this.doctorid = doctorid;
}
public Doctor() {}
public String getDoctorname() {
	return doctorname;
}

public void setDoctorname(String doctorname) {
	this.doctorname = doctorname;
}

public String getSpecialist() {
	return specialist;
}

public void setSpecialist(String specialist) {
	this.specialist = specialist;
}

public String getAppdate() {
	return appdate;
}



public void setAppdate(String appdate) {
	this.appdate = appdate;
}
}
