package com.cts.patient.bo;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cts.patient.dao.AddPatientDAOImp;
import com.cts.patient.model.PatientRegister;


@WebServlet("/PatientServlet")
public class PatientServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public PatientServlet() {
        super();
        
    }

	
	

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
        response.setContentType("text/html");
        out.println("<html><head><title>Invalid</title></head><body><center>");
	
		try
		{
		 String firstName=request.getParameter("firstname");
		 String lastName=request.getParameter("lastname");
		 int age=Integer.parseInt(request.getParameter("age"));
		 String gender=request.getParameter("gender");
		 long contactNumber=Long.parseLong(request.getParameter("mob"));
		 int userId=Integer.parseInt(request.getParameter("userid"));
         String password=request.getParameter("password");
         
         HttpSession s=request.getSession(false);
         s.setAttribute("userid", userId);
         PatientRegister p=new PatientRegister(firstName, lastName, age, gender, contactNumber,userId,  password);
         AddPatientDAOImp apd=new AddPatientDAOImp();
         int result=apd.addpatient(p);
         if(result==1)
         {  
        	 RequestDispatcher rd=request.getRequestDispatcher("patientdetailsform.jsp");
        	 out.println("<font color ='green'>Registered Successfully</font>");
        	 rd.include(request, response);
         }
        	 
         
         else
         {
        	 RequestDispatcher rd=request.getRequestDispatcher("patientregistration.jsp");
        	 out.println("<font color ='red'>Not Inserted</font>");
        	 rd.include(request, response);
         }
	}
		catch(Exception e)
		{
			System.out.println(e);
		}
		out.println("</center></body></html>");
}}
