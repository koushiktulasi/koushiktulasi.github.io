package com.cts.patient.bo;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cts.patient.dao.AddPatientDAOImp;
import com.cts.patient.model.PatientRegister;
import com.cts.patient.model.TreatmentDetails;


@WebServlet("/TreatmentDetails")
public class TreatmentDetailsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public TreatmentDetailsServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
        response.setContentType("text/html");
        out.println("<html><head><title>Invalid</title></head><body><center>");
		try
		{
			
	        HttpSession s=request.getSession(true);
	        int patientid=(int)(s.getAttribute("userid"));
		 String illness =request.getParameter("illness");
		 String status=request.getParameter("status");
		 String seriousness=request.getParameter("seriousness");
		 String doctorassign=request.getParameter("doctorassign");
		 
		 String ss[]=doctorassign.split(" ");
		 String doctorname=ss[0];
		 int doctorid=Integer.parseInt(ss[1]);
		 String bloodgroup=request.getParameter("bloodgroup");  
		 String address=request.getParameter("address");
		 String checkin=request.getParameter("checkin");
		
		
		
		 long contactnumber=Long.parseLong(request.getParameter("contactnumber"));
		 int height=Integer.parseInt(request.getParameter("height"));
		 int weight=Integer.parseInt(request.getParameter("weight"));
		 
        
        
         TreatmentDetails tr=new TreatmentDetails(patientid, checkin, illness, seriousness, contactnumber, bloodgroup, height, weight, address, status, doctorname, doctorid);
         AddPatientDAOImp apd=new AddPatientDAOImp();
         int result=apd.addtreatmentdetails(tr);
         if(result==1)
         {  
        	 RequestDispatcher rd=request.getRequestDispatcher("adminhome.jsp");
        	 out.println("<font color ='green'>Registered Successfully</font>");
        	 rd.include(request, response);
         }
        	 
         
         else
         {
        	 RequestDispatcher rd=request.getRequestDispatcher("patientdetailsform.jsp");
        	 out.println("<font color ='red'>Not Inserted</font>");
        	 rd.include(request, response);
         }
	}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		out.println("</center></body></html>");
	}

}
