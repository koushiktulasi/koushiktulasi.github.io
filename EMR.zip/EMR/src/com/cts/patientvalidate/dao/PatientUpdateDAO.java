package com.cts.patientvalidate.dao;

import com.cts.patientvalidate.model.PatientUpdateCredentials;

public interface  PatientUpdateDAO {
public int patientupdate(PatientUpdateCredentials p);
}
