package com.cts.patientvalidate.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.security.auth.message.callback.PrivateKeyCallback.Request;
import javax.servlet.http.HttpSession;

import com.cts.patientvalidate.model.PatientUpdateCredentials;
import com.cts.util.Db;

public class PatientUpdateDAOImp implements PatientUpdateDAO {

	@Override
	public int patientupdate(PatientUpdateCredentials p) {
		int result=0;
        PreparedStatement pst=null;
        PreparedStatement pst1=null;
        ResultSet rs=null;
        
      try
      {               
    	              
    	            	  if(p.getOriginalpassword().equals(p.getCurrentpassword()))
    	            	  {
                      pst = Db.getDb().prepareStatement("update patientlogin set password='"+p.getNewpassword()+"' where userid='"+p.getUserid()+"'");
                      pst1=Db.getDb().prepareStatement("update patient set password='"+p.getNewpassword()+"' where userid='"+p.getUserid()+"'");
                      result=pst.executeUpdate();
                      result=pst1.executeUpdate();
    	              }
    	              }
    	              
                      
      
      catch(Exception e)
      {
                      System.out.println(e);
      }
      return result;
	}

}
