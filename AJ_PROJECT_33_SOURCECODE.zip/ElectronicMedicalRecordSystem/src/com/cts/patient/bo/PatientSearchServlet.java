package com.cts.patient.bo;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.security.auth.message.callback.PrivateKeyCallback.IssuerSerialNumRequest;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.tomcat.util.buf.StringUtils;

import com.cts.patient.dao.AddPatientDAOImp;
import com.cts.patient.model.TreatmentDetails;

/**
 * Servlet implementation class PatientSearchServlet
 */
@WebServlet("/PatientSearch")
public class PatientSearchServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public PatientSearchServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
        response.setContentType("text/html");
        out.println("<html><head><title>PatientSearch</title></head><body><center>");
	   try
	   {TreatmentDetails t=new TreatmentDetails();
		String nameorid=(request.getParameter("nameorid"));
		t.setPatientid(Integer.parseInt(nameorid));
		
		
		AddPatientDAOImp ado=new AddPatientDAOImp();
		ArrayList<TreatmentDetails> al=ado.patientsearch(t);
		HttpSession s=request.getSession(false);
		s.setAttribute("al", al);
		if(al.isEmpty())
		{
		RequestDispatcher rd=request.getRequestDispatcher("patientsearchjsp.jsp");
		out.println("<br><br><br><br>");
		out.println("<h3><font color ='red'>Record Not Exist</font></h3>");
		rd.include(request, response);
		}
		else
		{
			RequestDispatcher rd=request.getRequestDispatcher("patientsearchjsp.jsp");
			rd.forward(request, response);
		}
		
	   }
	   catch(Exception e)
		{
			System.out.println(e);
		}
		out.println("</center></body></html>");
		
		
	}

}
