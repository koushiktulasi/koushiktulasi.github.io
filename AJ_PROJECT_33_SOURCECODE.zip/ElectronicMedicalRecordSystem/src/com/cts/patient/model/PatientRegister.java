package com.cts.patient.model;

public class PatientRegister {
  private String FirstName,LastName,Gender,Password;
  private int Age;
  private long ContactNumber,UserId;
  
public PatientRegister(String firstName, String lastName, int age,String gender,long contactNumber, long userId,String password) 
		 {
	super();
	FirstName = firstName;
	LastName = lastName;
	Gender = gender;
	Password = password;
	Age = age;
	ContactNumber = contactNumber;
	UserId = userId;
}
public PatientRegister() {}
public String getFirstName() {
	return FirstName;
}
public void setFirstName(String firstName) {
	FirstName = firstName;
}
public String getLastName() {
	return LastName;
}
public void setLastName(String lastName) {
	LastName = lastName;
}
public String getGender() {
	return Gender;
}
public void setGender(String gender) {
	Gender = gender;
}
public String getPassword() {
	return Password;
}
public void setPassword(String password) {
	Password = password;
}
public int getAge() {
	return Age;
}
public void setAge(int age) {
	Age = age;
}
public long getContactNumber() {
	return ContactNumber;
}
public void setContactNumber(long contactNumber) {
	ContactNumber = contactNumber;
}
public long getUserId() {
	return UserId;
}
public void setUserId(long userId) {
	UserId = userId;}
}

