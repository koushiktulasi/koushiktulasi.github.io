package com.cts.patientvalidate.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.security.auth.message.callback.PrivateKeyCallback.Request;
import javax.servlet.http.HttpSession;

import com.cts.patient.model.PatientRegister;
import com.cts.patient.model.TreatmentDetails;
import com.cts.patientvalidate.model.PatientUpdateCredentials;
import com.cts.util.Db;

public class PatientUpdateDAOImp implements PatientUpdateDAO {

	@Override
	public int patientupdate(PatientUpdateCredentials p) {
		int result=0;
        PreparedStatement pst=null;
        PreparedStatement pst1=null;
        ResultSet rs=null;
        
      try
      {               
    	              
    	            	  if(p.getOriginalpassword().equals(p.getCurrentpassword()))
    	            	  {
                      pst = Db.getDb().prepareStatement("update patientlogin set password='"+p.getNewpassword()+"' where userid='"+p.getUserid()+"'");
                      pst1=Db.getDb().prepareStatement("update patient set password='"+p.getNewpassword()+"' where userid='"+p.getUserid()+"'");
                      result=pst.executeUpdate();
                      result=pst1.executeUpdate();
    	              }
    	              }
    	              
                      
      
      catch(Exception e)
      {
                      System.out.println(e);
      }
      return result;
	}

	@Override
	public int patientbasicdetails(TreatmentDetails t, PatientRegister p) {
		int result=0,result1=0;
		int res=0;
        PreparedStatement pst=null;
        PreparedStatement pst1=null;
  
        try
        {
        	pst =Db.getDb().prepareStatement("update treatmentdetails set address='"+t.getAddress()+"',contactnumber='"+t.getContactnumber()+"' where patientid='"+t.getPatientid()+"'");
        	//System.out.println(t.getContactnumber()+"   "+t.getPatientid()+"    "+t.getAddress());
            pst1=Db.getDb().prepareStatement("update patient set age='"+p.getAge()+"',contactnumber='"+p.getContactNumber()+"' where userid='"+p.getUserId()+"'");
           // System.out.println(p.getAge()+"    "+p.getContactNumber()+"   "+p.getUserId());
        	result=pst.executeUpdate();
        	result=pst1.executeUpdate();
        	
        	//res=result+result1;
        	//System.out.println(result);
        
        }
        catch(Exception e)
        {
        //	System.out.println(e);
        	e.printStackTrace();
        }
		return result;
	}

	@Override
	public ArrayList<TreatmentDetails> viewdetails(TreatmentDetails t) {
		PreparedStatement pst=null;
	    ArrayList<TreatmentDetails> al1=new ArrayList<>();
	    ResultSet rs=null;
	    try
	    {
	    	
	      String s="undergoing";
	    	pst=Db.getDb().prepareStatement("select * from treatmentdetails where patientid='"+t.getPatientid()+"' and status='"+s+"'");
	    	rs=pst.executeQuery();
	    	while(rs.next())
	    	{
	    		TreatmentDetails t1=new TreatmentDetails(rs.getInt(1),rs.getString(2), rs.getString(3),  rs.getString(4), rs.getString(5), rs.getLong(6),
	    		rs.getString(7),  rs.getInt(8), rs.getInt(9), rs.getString(10), rs.getString(11), rs.getString(12),rs.getInt(13),rs.getString(14));
	    	al1.add(t1);
	    	
	    	}
	    	
	    }
	    catch(Exception e)
	    {
	    	e.printStackTrace();		 
	    	}
	    return al1;
	}

	@Override
	public ArrayList<TreatmentDetails> historydetails(TreatmentDetails t) {
		PreparedStatement pst=null;
	    ArrayList<TreatmentDetails> al2=new ArrayList<>();
	    ResultSet rs=null;
	    try
	    {
	    	
	      String s="undergone";
	    	pst=Db.getDb().prepareStatement("select * from treatmentdetails where patientid='"+t.getPatientid()+"' and status='"+s+"'");
	    	rs=pst.executeQuery();
	    	while(rs.next())
	    	{
	    		TreatmentDetails t1=new TreatmentDetails(rs.getInt(1),rs.getString(2), rs.getString(3),  rs.getString(4), rs.getString(5), rs.getLong(6),
	    		rs.getString(7),  rs.getInt(8), rs.getInt(9), rs.getString(10), rs.getString(11), rs.getString(12),rs.getInt(13),rs.getString(14));
	    	al2.add(t1);
	    	
	    	}
	    	
	    }
	    catch(Exception e)
	    {
	    	e.printStackTrace();		 
	    	}
	    return al2;
	}

}
