package com.cts.patientvalidate.dao;

import com.cts.patientvalidate.model.PatientCredentials;
import com.cts.patientvalidate.model.Session;

public interface PatientValidateDAO {
public int patientlogin(PatientCredentials p);
public int session(Session se);
}
