package com.cts.patientvalidate.dao;

import java.util.ArrayList;

import com.cts.patient.model.PatientRegister;
import com.cts.patient.model.TreatmentDetails;
import com.cts.patientvalidate.model.PatientUpdateCredentials;

public interface  PatientUpdateDAO {
public int patientupdate(PatientUpdateCredentials p);
public int patientbasicdetails(TreatmentDetails t,PatientRegister p);
public ArrayList<TreatmentDetails> viewdetails(TreatmentDetails t);
public ArrayList<TreatmentDetails> historydetails(TreatmentDetails t);
}
