package com.cts.patientvalidate.bo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cts.patientvalidate.dao.PatientUpdateDAOImp;
import com.cts.patientvalidate.dao.PatientValidateDAOImp;
import com.cts.patientvalidate.model.PatientCredentials;
import com.cts.patientvalidate.model.PatientUpdateCredentials;

@WebServlet("/PatientUpdate")
public class PasswordUpdate extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public PasswordUpdate() {
        super();
       
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
        response.setContentType("text/html");
        out.println("<html><head><title>Invalid</title></head><body><center>");
        try
        {
		HttpSession s=request.getSession(false);
	     int userid=(int)s.getAttribute("ref1");
	     String originalpassword=(String)s.getAttribute("pass");
	     String currentpassword=request.getParameter("currentpassword");
         String newpassword=request.getParameter("newpassword");
         PatientUpdateCredentials p=new PatientUpdateCredentials(userid, currentpassword, newpassword,originalpassword);
         PatientUpdateDAOImp puo=new PatientUpdateDAOImp();
         int result=puo.patientupdate(p);
         if(result==1)
         {
                        
                         
                         RequestDispatcher rd=request.getRequestDispatcher("patientlanding.jsp");
                         out.println("<script type=\"text/javascript\">");
                         out.println("alert('Password Updated Successfully');");
                         out.println("</script>");
                         rd.include(request, response);
         }
         else
         {
                         RequestDispatcher rd=request.getRequestDispatcher("updatepassword.jsp");
                         out.println("<script type=\"text/javascript\">");
                         out.println("alert('Enter correct current password');");
                         out.println("</script>");
                         rd.include(request, response);
         }
}
catch(Exception e)
{
           System.out.println(e);
}
out.println("</center></body></html>");
	}

}
