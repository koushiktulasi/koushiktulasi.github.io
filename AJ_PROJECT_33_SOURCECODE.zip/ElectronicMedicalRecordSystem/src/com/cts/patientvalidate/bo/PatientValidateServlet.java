package com.cts.patientvalidate.bo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cts.admin.dao.AdminDAOImp;
import com.cts.admin.model.Admin;
import com.cts.patientvalidate.dao.PatientValidateDAO;
import com.cts.patientvalidate.dao.PatientValidateDAOImp;
import com.cts.patientvalidate.model.PatientCredentials;

@WebServlet("/PatientValidateServlet")
public class PatientValidateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public PatientValidateServlet() {
        super();
        
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 PrintWriter out=response.getWriter();
         response.setContentType("text/html");
         out.println("<html><head><title>Invalid</title></head><body><center>");
         try
         {
        	           HttpSession s=request.getSession(true);
                       int userid=Integer.parseInt(request.getParameter("userid"));
                       String password=request.getParameter("password");
                       PatientCredentials p=new PatientCredentials(userid, password);
                       PatientValidateDAOImp pvo=new PatientValidateDAOImp();
                       int result=pvo.patientlogin(p);
                       if(result==1)
                       {
                                      
                                       s.setAttribute("ref1",userid);
                                       s.setAttribute("pass", password);
                                       RequestDispatcher rd=request.getRequestDispatcher("patientlanding.jsp");
                                       rd.forward(request, response);
                       }
                       else
                       {
                                       RequestDispatcher rd=request.getRequestDispatcher("patientlogin.jsp");
                                       out.println("<script type=\"text/javascript\">");
                                       out.println("alert('Username or Password Incorrect');");
                                       out.println("</script>");
                                       rd.include(request, response);
                       }
}
         catch(Exception e)
         {
                         System.out.println(e);
         }
         out.println("</center></body></html>");
	}

}
