package com.cts.patientvalidate.model;

public class Session {
public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public String getLogin() {
		return login;
	}
	public void setLogin(String login) {
		this.login = login;
	}
	public String getLogout() {
		return logout;
	}
	public void setLogout(String logout) {
		this.logout = logout;
	}
private int userid;
private String login;
private String logout;
public Session(int userid, String login, String logout) {
	super();
	this.userid = userid;
	this.login = login;
	this.logout = logout;
}
public Session() {}
}
