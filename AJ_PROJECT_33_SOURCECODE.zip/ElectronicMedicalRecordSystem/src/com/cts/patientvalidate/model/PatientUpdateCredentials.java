package com.cts.patientvalidate.model;

public class PatientUpdateCredentials {
    private String currentpassword,newpassword,originalpassword;
    private int userid;
	public String getCurrentpassword() {
		return currentpassword;
	}

	public void setCurrentpassword(String currentpassword) {
		this.currentpassword = currentpassword;
	}

	public String getNewpassword() {
		return newpassword;
	}

	public void setNewpassword(String newpassword) {
		this.newpassword = newpassword;
	}

	public PatientUpdateCredentials(int userid,String currentpassword, String newpassword,String originalpassword) {
		super();
		this.userid=userid;
		this.currentpassword = currentpassword;
		this.newpassword = newpassword;
		this.originalpassword=originalpassword;
	}

	public String getOriginalpassword() {
		return originalpassword;
	}

	public void setOriginalpassword(String originalpassword) {
		this.originalpassword = originalpassword;
	}

	public int getUserid() {
		return userid;
	}

	public void setUserid(int userid) {
		this.userid = userid;
	}
    
}
