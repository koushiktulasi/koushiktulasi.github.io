package com.cts.patient.bo;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cts.patient.dao.AddPatientDAOImp;
import com.cts.patient.model.Doctor;
import com.cts.patient.model.PatientRegister;



@WebServlet("/AddDoctor")
public class AddDoctor extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public AddDoctor() {
        super();
        // TODO Auto-generated constructor stub
    }

	
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
        response.setContentType("text/html");
        out.println("<html><head><title>Invalid</title></head><body><center>");
	
		try
		{
		 String doctorname=request.getParameter("doctorname");
		 String specialist=request.getParameter("specialist");
		 String appdate=request.getParameter("appdate");
		 int doctorid=Integer.parseInt(request.getParameter("doctorid"));
		/* SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
		  Date d=sdf2.parse(appdate);
		  String appdate1=sdf2.format(d);*/
		 
			
		Doctor dc=new  Doctor(doctorname, specialist, appdate,doctorid);
         AddPatientDAOImp apd=new AddPatientDAOImp();
         int result=apd.adddoctor(dc);
         if(result==1)
         {  
        	 RequestDispatcher rd=request.getRequestDispatcher("doctor.jsp");
        	 out.println("<font color ='green'>Registered Successfully</font>");
        	 rd.include(request, response);
         }
        	 
         
         else
         {
        	 RequestDispatcher rd=request.getRequestDispatcher("doctor.jsp");
        	 out.println("<font color ='red'>Not Inserted</font>");
        	 rd.include(request, response);
         }
	}
		catch(Exception e)
		{
			System.out.println(e);
		}
		out.println("</center></body></html>");
	}
}



	
	


