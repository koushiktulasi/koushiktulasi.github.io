package com.cts.patient.bo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cts.patient.dao.AddPatientDAOImp;
import com.cts.patient.model.TreatmentDetails;


@WebServlet("/PatientUpdation")
public class PatientUpdationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public PatientUpdationServlet() {
        super();
       
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
        response.setContentType("text/html");
        out.println("<html><head><title>Invalid</title></head><body><center>");
        try
		{
        	int patientid=Integer.parseInt(request.getParameter("patientid"));
		 String bedstatus=request.getParameter("bedstatus");
		 String checkout=request.getParameter("checkout");
		 int weight=Integer.parseInt(request.getParameter("weight"));
		 String status=request.getParameter("status");
		 TreatmentDetails t=new TreatmentDetails();
		 t.setPatientid(patientid);
		 t.setBedstatus(bedstatus);
		 t.setCheckout(checkout);
		 t.setWeight(weight);
		 t.setStatus(status);
		 AddPatientDAOImp apd=new AddPatientDAOImp();
		 int result=apd.updatetreatmentdetails(t);
		 if(result==1)
         {  
        	 RequestDispatcher rd=request.getRequestDispatcher("adminhome.jsp");
        	 out.println("<font color ='green'>UpdatedSuccessfully </font>");
        	 rd.include(request, response);
         }
        	 
         
         else
         {
        	 RequestDispatcher rd=request.getRequestDispatcher("patientedit.jsp");
        	 out.println("<font color ='red'>Not Inserted</font>");
        	 rd.include(request, response);
         }}
	
		catch(Exception e)
		{
			e.printStackTrace();
		}
		out.println("</center></body></html>");
		}
	}


