package com.cts.patient.bo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cts.patient.dao.AddPatientDAOImp;
import com.cts.patient.model.Doctor;
import com.cts.patient.model.TreatmentDetails;


@WebServlet("/UpdateDoctor")
public class UpdateDoctorServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public UpdateDoctorServlet() {
        super();
       
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
        response.setContentType("text/html");
        out.println("<html><head><title>Invalid</title></head><body><center>");
        try
		{
        	int doctorid=Integer.parseInt(request.getParameter("doctorid"));
		 String appdate=request.getParameter("appdate");
		
		
		 Doctor d=new Doctor();
		 d.setDoctorid(doctorid);
		d.setAppdate(appdate);
		 AddPatientDAOImp apd=new AddPatientDAOImp();
		 int result=apd.updatedoctor(d);
		 if(result==1)
         {  
        	 RequestDispatcher rd=request.getRequestDispatcher("adminhome.jsp");
        	 out.println("<font color ='green'>UpdatedSuccessfully </font>");
        	 rd.include(request, response);
         }
        	 
         
         else
         {
        	 RequestDispatcher rd=request.getRequestDispatcher("doctorupdateedit.jsp");
        	 out.println("<font color ='red'>Not Inserted</font>");
        	 rd.include(request, response);
         }}
	
		catch(Exception e)
		{
			e.printStackTrace();
		}
		out.println("</center></body></html>");
	}

}
