package com.cts.patientvalidate.bo;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cts.patient.dao.AddPatientDAOImp;
import com.cts.patient.model.PatientRegister;
import com.cts.patient.model.TreatmentDetails;
import com.cts.patientvalidate.dao.PatientUpdateDAOImp;
import com.cts.patientvalidate.model.PatientCredentials;


@WebServlet("/PatientBasicUpdation")
public class PatientBasicUpdationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public PatientBasicUpdationServlet() {
        super();
      
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
        response.setContentType("text/html");
        out.println("<html><head><title>Invalid</title></head><body><center>");
        try
		{
		 
		long contactNumber=Long.parseLong(request.getParameter("contactnumber"));
		 int age=Integer.parseInt(request.getParameter("age"));
		 String address=request.getParameter("address");
		 int patientid=Integer.parseInt(request.getParameter("patientid"));
		 int userid=Integer.parseInt(request.getParameter("userid"));
		 PatientRegister p=new PatientRegister();
		 TreatmentDetails t=new TreatmentDetails();
		 p.setAge(age);
		 p.setContactNumber(contactNumber);
		 p.setUserId(userid);
		 t.setPatientid(patientid);
	   	t.setAddress(address);
		t.setContactnumber(contactNumber);
		 PatientUpdateDAOImp pud=new PatientUpdateDAOImp();
		 int result=pud.patientbasicdetails(t, p);
		 
		 if(result==1)
         {  
        	 RequestDispatcher rd=request.getRequestDispatcher("patientupdateedit.jsp");
        	 out.println("<font color ='green'>Registered Successfully</font>");
        	 rd.include(request, response);
         }
        	 
         
         else
         {
        	 RequestDispatcher rd=request.getRequestDispatcher("patientdetailsform.jsp");
        	 out.println("<font color ='red'>Not Inserted</font>");
        	 rd.include(request, response);
         }}
	
		catch(Exception e)
		{
			e.printStackTrace();
		}
		out.println("</center></body></html>");
		}
	}


