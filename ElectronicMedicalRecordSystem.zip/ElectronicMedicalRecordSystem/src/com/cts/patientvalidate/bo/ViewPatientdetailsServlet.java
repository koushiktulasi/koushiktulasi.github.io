package com.cts.patientvalidate.bo;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cts.patient.model.TreatmentDetails;
import com.cts.patientvalidate.dao.PatientUpdateDAOImp;


@WebServlet("/ViewPatientdetails")
public class ViewPatientdetailsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public ViewPatientdetailsServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
        response.setContentType("text/html");
        out.println("<html><head><title>Invalid</title></head><body><center>");
        try
        {
		HttpSession s=request.getSession(false);
		int patientid=(int)(s.getAttribute("ref1"));
		TreatmentDetails t=new TreatmentDetails();
		t.setPatientid(patientid);
		PatientUpdateDAOImp pud=new PatientUpdateDAOImp();
		ArrayList<TreatmentDetails> al1=pud.viewdetails(t);
		
		 //HttpSession s=request.getSession(false);
			s.setAttribute("al1", al1);
			
			if(al1.isEmpty())
			{
			RequestDispatcher rd=request.getRequestDispatcher("viewpatientdetails.jsp");
			out.println("<h3><font color ='red'>Sorry your are currently not undergoing any Treatment</font></h3>");
			rd.include(request, response);
			}
			else
			{
				RequestDispatcher rd=request.getRequestDispatcher("viewpatientdetails.jsp");
				rd.forward(request, response);
			}
			
	}
        catch(Exception e)
        {
        	e.printStackTrace();
        }

}
}
