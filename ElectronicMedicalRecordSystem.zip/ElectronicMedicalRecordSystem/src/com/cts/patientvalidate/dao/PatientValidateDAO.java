package com.cts.patientvalidate.dao;

import com.cts.patientvalidate.model.PatientCredentials;

public interface PatientValidateDAO {
public int patientlogin(PatientCredentials p);
}
