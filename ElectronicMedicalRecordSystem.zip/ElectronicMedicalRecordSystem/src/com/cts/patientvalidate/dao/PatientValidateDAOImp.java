package com.cts.patientvalidate.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.cts.patientvalidate.model.PatientCredentials;
import com.cts.util.Db;

public class PatientValidateDAOImp implements PatientValidateDAO{

	@Override
	public int patientlogin(PatientCredentials p) {
		int result=0;
        PreparedStatement pst=null;
        ResultSet rs=null;
      try
      {
                      pst = Db.getDb().prepareStatement("select * from patientlogin");
                      rs=pst.executeQuery();
                      while(rs.next())
                      {
                                      if(p.getUserid()==rs.getInt(1)&&p.getPassword().equals(rs.getString(2)))
                                      {
                                                      result=1;
                                                      break;
                                                                                      
                                      }
                      }
      }
      catch(Exception e)
      {
                      System.out.println(e);
      }
      return result;
		
	}
  
}
